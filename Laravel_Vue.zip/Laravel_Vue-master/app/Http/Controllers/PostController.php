<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Inertia\Inertia;

class PostController extends Controller
{
    public function index()
    {
        return Inertia::render('Post/IndexPost', [
            'posts' => Post::all()
        ]);
    }

    public function create()
    {
        return Inertia::render('Post/CreatePost');
    }

    public function store(Request $request)
    {
        $post = new Post();
        $post->title = $request->title;
        $post->body = $request->body;

        if (auth()->check()) {
            $post->user_id = auth()->id();
        } else {
            $post->user_id = 1;
        }

        $post->save();
        return redirect()->route('posts.index');
    }


    public function show(Post $post)
    {
        $post->load('user');

        return Inertia::render('Post/ShowPost', [
            'post' => $post,
        ]);
    }

    public function edit(Post $post)
    {
        return Inertia::render('Post/EditPost', [
            'post' => $post
        ]);
    }

    public function update(Request $request, Post $post)
    {
        $post->title = $request->title;
        $post->body = $request->body;
        $post->save();
    }

    public function destroy(Post $post)
    {
        $post->delete();
        return redirect()->route('posts.index');
    }
}
