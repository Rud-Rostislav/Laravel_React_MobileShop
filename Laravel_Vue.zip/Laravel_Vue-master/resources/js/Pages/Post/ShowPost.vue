<script setup>
import {Link, usePage} from '@inertiajs/vue3';
import DropdownLink from "@/Components/DropdownLink.vue";

defineProps(['post', 'user']);

const page = usePage();

const formatDateTime = (dateTime) => {
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric'
    };
    return new Date(dateTime).toLocaleString(undefined, options);
};

const deletePost = async (post) => {
    try {
        await page.inertia.delete(route('posts.destroy', post.id));
    } catch (error) {
    }
};
</script>

<template>
    <div
        style="box-shadow: rgb(0 0 0) 0 0 5px -2px; border-radius: 10px; padding: 25px; display: flex; flex-direction: column;
    justify-content: space-between; height: 50vh; width: 50vw; margin: 25vh auto"
    >
        <div>
            <p>Created by {{ post.user_id }}. {{ post.user.name }} | {{ post.user.email }}</p>
            <p>Created at: {{ formatDateTime(post.created_at) }}</p>
            <p>Updated at: {{ formatDateTime(post.updated_at) }}</p>
        </div>

        <div>
            <h1>{{ post.id }}. {{ post.title }}</h1>
            <p>{{ post.body }}</p>
        </div>

        <div style="display: flex">
            <Link :href="route('posts.index')" class="link">Go to all</Link>
            <Link :href="route('posts.edit', post.id)" class="link" style="background: #b49967">Edit post</Link>
            <Link :href="route('posts.destroy', post.id)" method="delete" style="background: #ef4444" class="link">
                Delete Post
            </Link>
        </div>
    </div>
</template>

<style scoped>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-align: center;
}

button, .link {
    display: flex;
    justify-content: center;
    background: #2563eb;
    color: white;
    padding: 10px 10px;
    width: 10vw;
    margin: 10px auto;
    border-radius: 20px
}

.link:hover {
    transition: 0.5s;
    transform: scale(1.1);
}

.link:not(:hover) {
    transition: 0.5s;
}

.post:hover {
    transition: 1s;
    transform: scale(1.05);
}

.post:not(:hover) {
    transition: 1s;
}
</style>
