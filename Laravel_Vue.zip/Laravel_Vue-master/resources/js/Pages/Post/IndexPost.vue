<script setup>
import {Link} from '@inertiajs/vue3';

defineProps({posts: Array});
</script>

<template>
    <h1 style="margin-top: 25px; font-size: 1.5rem">All Posts</h1>
    <Link :href="route('posts.create')" class="link">Create post</Link>

    <p v-if="posts.length === 0">No posts yet</p>
    <div style="display: flex ; flex-wrap: wrap; gap: 25px; justify-content: center; padding: 25px">
        <div v-for="post in posts" style="display: flex; flex-wrap: wrap; flex-direction: column; justify-content: space-between;
        width: 30vw; min-height: 30vh; box-shadow: rgb(0 0 0) 0 0 5px -2px; padding: 25px; border-radius: 10px"
             class="post">
            <div>
                <p>{{ post.title }}</p>
                <p>{{ post.body }}</p>
            </div>
            <Link :href="route('posts.show', post.id)" class="link">More</Link>
        </div>
    </div>
</template>

<style scoped>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-align: center;
}

button, .link {
    display: flex;
    justify-content: center;
    background: #2563eb;
    color: white;
    padding: 10px 10px;
    width: 10vw;
    margin: 10px auto;
    border-radius: 20px
}

.post:hover {
    transition: 1s;
    transform: scale(1.05);
}

.post:not(:hover) {
    transition: 1s;
}
</style>
