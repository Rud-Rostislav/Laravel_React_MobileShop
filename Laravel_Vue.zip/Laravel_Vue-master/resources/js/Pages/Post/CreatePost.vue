<template>
    <div style="height: 50vw; display: flex; flex-direction: column; justify-content: center">
        <h1 style="margin-top: 25px">Create post</h1>
        <form @submit.prevent="handleSubmit">
            <input v-model="title" type="text" placeholder="Title"/>
            <textarea v-model="body" placeholder="Body"></textarea>
            <button type="submit" style="background: #2563eb; border-radius: 10px; padding: 5px 10px; color: white">
                Create post
            </button>
        </form>
    </div>
</template>

<script>
export default {
    data() {
        return {
            title: '',
            body: '',
        };
    },
    methods: {
        handleSubmit() {
            axios.post('/posts', {
                title: this.title,
                body: this.body,
            })
            return this.$inertia.visit('/posts');
        },
    },
};
</script>

<style scoped>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-align: center;
}

input, textarea {
    display: flex;
    justify-content: center;
    padding: 10px 10px;
    width: 25vw;
    margin: 10px auto;
    border-radius: 20px;
}

textarea {
    min-height: 20vh;
    max-height: 20vh;
}
</style>
