Create project, add Vue:
composer create-project laravel/laravel laravel_vue
composer require laravel/breeze --dev
php artisan breeze:install vue

DB:
Delete all DB and stay only
DB_CONNECTION=sqlite
php artisan migrate

RUN:
php artisan serve
npm run dev

Create Model, migration, controller in a single command:
php artisan make:model -mrc Post

Create fake posts by using factory:
php artisan make:factory PostFactory
php artisan migrate:fresh --seed
